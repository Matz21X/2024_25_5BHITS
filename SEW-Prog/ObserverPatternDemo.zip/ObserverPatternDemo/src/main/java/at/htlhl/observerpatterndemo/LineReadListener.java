package at.htlhl.observerpatterndemo;

/**
 * Observer interface
 */

public interface LineReadListener {
    public void lineRead(String text);
}

